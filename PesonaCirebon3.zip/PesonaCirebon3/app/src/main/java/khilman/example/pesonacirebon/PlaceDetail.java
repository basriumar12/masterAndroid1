package khilman.example.pesonacirebon;

import android.support.v7.app.ActionBar;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.support.v7.widget.Toolbar;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class PlaceDetail extends AppCompatActivity {
    TextView postDesc;
    ImageView postImage;
    int[] thumb = {R.drawable.gua_sunyagi, R.drawable.keraton_kanoman, R.drawable.masjid_agung, R.drawable.keraton_kasepuhan, R.drawable.masjid_agung, R.drawable.masjid_agung};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_place_detail);
        postDesc = (TextView) findViewById(R.id.postDesc);
        postImage = (ImageView) findViewById(R.id.postImage);

        postDesc.setText(getIntent().getStringExtra("postDesc"));
        int thumbId = Integer.parseInt(getIntent().getStringExtra("postImage"));
        postImage.setImageResource(thumb[thumbId]);
    }

}
