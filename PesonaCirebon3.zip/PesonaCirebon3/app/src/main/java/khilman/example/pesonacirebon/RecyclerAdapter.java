package khilman.example.pesonacirebon;

import android.content.Context;
import android.content.Intent;
import android.support.v7.widget.RecyclerView;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import java.util.zip.Inflater;

import static android.R.attr.name;
import static android.R.attr.thumb;
import static android.R.attr.title;

/**
 * Created by root on 26/07/17.
 */

public class RecyclerAdapter extends RecyclerView.Adapter<RecyclerViewHolder> {
    // deklarasi variable context
    private final Context context;
    // menyimpan judul dalam bentuk array
    String [] title = {"Gua Sunyaragi", "Keraton Kanoman", "Masjid Agung Raya", "Keraton Kasepuhan", "Masjid Agung", "Keraton"};
    int[] thumb = {R.drawable.gua_sunyagi, R.drawable.keraton_kanoman, R.drawable.masjid_agung, R.drawable.keraton_kasepuhan, R.drawable.masjid_agung, R.drawable.gua_sunyagi};
    int[] thumbId = {0,1,2,3,4,5};
    String [] desc = {"Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\n" +
            "tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\n" +
            "quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\n" +
            "consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\n" +
            "cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\n" +
            "proident, sunt in culpa qui officia deserunt mollit anim id est laborum.",

            "strud eis nisi ut aliquip ex ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\n" +
                    "tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\n" +
                    "quis nostrud eis nisi ut  ex ea commodo\n" +
                    "consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\n" +
                    "cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\n" +
                    "proident, sunt in culpa qui offialiquipnt mollit anim id est laborum.",

            "eu fugiat nulla pasit amet, consectetur adipisicing elit, sed do eiusmod\n" +
                    "tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\n" +
                    "quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\n" +
                    "consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\n" +
                    "cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\n" +
                    "proident, sunt in culpa qui officia deserunt mollit anim id est laborum.",

            " eu fugiat nulla pariatursectetur adipisicing elit, sed do eiusmod\n" +
                    "tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\n" +
                    "quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\n" +
                    "consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\n" +
                    "cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\n" +
                    "proident, sunt in culpa qui officia deserunt mollit anim id est laborum.",

            "lla pariatur. Excepteur sint  ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod\n" +
                    "tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\n" +
                    "quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\n" +
                    "consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\n" +
                    "cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\n" +
                    "proident, sunt in culpa qui officia deserunt mollit anim id est laborum.",

            "Loncididunt ut labore et dolore magna aliqua. Udolor sit amet, consectetur adipisicing elit, sed do eiusmod\n" +
                    "tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,\n" +
                    "quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo\n" +
                    "consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse\n" +
                    "cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non\n" +
                    "proident, sunt in culpa qui officia deserunt mollit anim id est laborum."
    };

    LayoutInflater inflater;
    public RecyclerAdapter(Context context){
        this.context = context;
        inflater = LayoutInflater.from(context);
    }

    @Override
    public RecyclerViewHolder onCreateViewHolder(ViewGroup parent, int position) {
        View v =  inflater.inflate(R.layout.item_list, parent, false);
        RecyclerViewHolder viewHolder = new RecyclerViewHolder(v);
        return viewHolder;
    }

    @Override
    public void onBindViewHolder(RecyclerViewHolder holder, int position) {
        holder.tv1.setText(title[position]);
        holder.tv1.setOnClickListener(clickListener);
        holder.imageView.setImageResource(thumb[position]);
        holder.imageView.setOnClickListener(clickListener);
        //holder.tv2.setOnClickListener(clickListener);
        holder.tv1.setTag(holder);
        holder.imageView.setTag(holder);
    }


    View.OnClickListener clickListener = new View.OnClickListener(){
        @Override
        public void onClick(View view) {
            // memberi aksi saat cardview di click berdasarkan posisi tertentu
            RecyclerViewHolder vholder = (RecyclerViewHolder) view.getTag();
            int position = vholder.getPosition();
            Intent intent = new Intent(context, PlaceDetail.class);
            intent.putExtra("postDesc", desc[position]);
            intent.putExtra("postTitle", desc[position]);
            intent.putExtra("postImage", "" + thumbId[position]);
            context.startActivity(intent);
            //Toast.makeText(context, "Menu ini berada di posisi " + position, Toast.LENGTH_LONG).show();
        }
    };

    @Override
    public int getItemCount() {
        return title.length;
    }
}
