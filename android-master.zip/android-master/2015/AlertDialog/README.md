Dialog
--

![dialog](window.png)

![dialog](dialog.png)