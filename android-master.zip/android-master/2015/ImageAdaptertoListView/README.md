use adapter to fill data from ArrayList to ListView
--

![screenshot](main.png)

![screenshot](dialog.png)

![screenshot](gallery.png)

![screenshot](image.png)

![screenshot](listview.png)