#Resumable Downloader

##V1. Resumable downloader feedback message screen & logcat
![resumable_download](resumable_download.png)


##V2. Resumable downloader all feedback message on screen
![resumable_download](resumable_download1.png)

![resumable_download](resumable_download2.png)

![resumable_download](resumable_download3.png)

![resumable_download](resumable_download4.png)