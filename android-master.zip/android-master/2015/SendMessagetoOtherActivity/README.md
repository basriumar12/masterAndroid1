Send a message from one activity to another activity
--

![screenshot](write.png)


![screenshot](receive.png)