Choose Image from Gallery or Camera, display in a ListView and save 
information in SQLite
--

Main view when start

![screen captures](main.png)

Popup window for options

![screen captures](dialog.png)

ListView in main window: Portrait View

![screen captures](listp.png)

ImageView in image view window: Portrait View

![screen captures](imagep.png)

ListView in main window: Landscape View

![screen captures](listl.png)

ImageView in image view window: Landscape View

![screen captures](imagel.png)

Popup window for options: choose photo from gallery, Landscape View

![screen captures](galleryl.png)