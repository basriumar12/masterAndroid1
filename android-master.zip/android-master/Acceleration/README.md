Android Sensor: Acceleration
