Learn Android Programming From Scratch
==
Course provide by [udemy](https://www.udemy.com/learn-android-programming-from-scratch-beta/#/)

Lecture 2: Course Sumary
--

Lecture 3: Android Installation process
--


