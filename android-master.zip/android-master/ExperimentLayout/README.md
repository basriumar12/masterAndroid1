Android Layout
--

![](http://developer.android.com/images/layoutparams.png)

```
    android:gravity
```
sets the gravity of the content of the View it used on


```
    android:layout_gravity
```
sets the gravity of the View or Layout in its parent

---

[ISO 639 : standardized nomenclature used to classify all known languages](https://en.wikipedia.org/wiki/List_of_ISO_639-1_codes)

chinese: zh

support other languages:
make a folder named values-zh under res/
make a strings.xml and set in all variables with suppoting languages

----
Toast
- a Toast provides simple feedback about operation...

Toast.makeText(context, text, duration).show();

----

        -------
                marging
                        --------
                                border
                                        --------
                                                padding
                                                        --------
                                                        | content |
                                                         --------


-----

