Android
=======

Android application development

Topics A:
--
[Android Studio](AndroidStudio.md)

[Android Build Process](buildprocess.md)

[Developer Workflow](DeveloperWorkflow.md)

[Android System Architechture](androidSystemArchitechture.md)

[Android Application fundamentals](ApplicationFundamentals.md)

[Android Fundamental](Sunshine/README.md)


Topics B:
--
[Gradle](Gradle.md)

[Design](design.md)

[Git](Sunshine/git.md)

[SQLite](Sunshine/sqlite/README.md)

