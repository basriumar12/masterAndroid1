Android Saving Data in SQLite Database
--

![screenshot](send.png)
![screenshot](view.png)