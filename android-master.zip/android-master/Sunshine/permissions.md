System Permissions
==
Android is a privilege-separated operating system, in which each application runs with a distinct system identity (Linux user ID & Group ID). 
- Parts of the system are also separated into distinct identities. 
- Linux thereby isolates applications from each other and from the system.

