SQLite
==

7 SQLite
--
[Command Line Shell For SQLite](http://www.sqlite.org/cli.html)

[Datatypes in SQLite Version 3](http://www.sqlite.org/datatype3.html)

--
list out all tables:
- .tables

find out how the talbes were created in database:
- .schema

print out table with header on:
- .header on
- SELECT * FROM weather;

exit:
- .quit
